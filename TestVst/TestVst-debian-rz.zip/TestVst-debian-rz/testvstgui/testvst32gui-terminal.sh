#!/bin/bash
chmod +x ./testvst32-batch
./testvst32gui
