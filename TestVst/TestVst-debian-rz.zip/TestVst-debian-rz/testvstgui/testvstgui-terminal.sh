#!/bin/bash
chmod +x ./testvst-batch
./testvstgui
